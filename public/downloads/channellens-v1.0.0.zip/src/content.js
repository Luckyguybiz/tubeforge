// Design System — Apple-inspired minimal aesthetic
// All styles injected into Shadow DOM to isolate from YouTube

const COLORS = {
  bg: 'rgba(28, 28, 30, 0.92)',
  bgSolid: '#1c1c1e',
  surface: 'rgba(44, 44, 46, 0.8)',
  surfaceHover: 'rgba(58, 58, 60, 0.8)',
  border: 'rgba(255, 255, 255, 0.06)',
  borderLight: 'rgba(255, 255, 255, 0.1)',
  text: '#f5f5f7',
  textSecondary: 'rgba(255, 255, 255, 0.55)',
  textTertiary: 'rgba(255, 255, 255, 0.35)',
  accent: '#0a84ff',
  accentSoft: 'rgba(10, 132, 255, 0.15)',
  green: '#30d158',
  greenSoft: 'rgba(48, 209, 88, 0.15)',
  red: '#ff453a',
  redSoft: 'rgba(255, 69, 58, 0.15)',
  orange: '#ff9f0a',
  orangeSoft: 'rgba(255, 159, 10, 0.15)',
  purple: '#bf5af2',
  purpleSoft: 'rgba(191, 90, 242, 0.15)',
  yellow: '#ffd60a',
  chartLine: '#0a84ff',
  chartFill: 'rgba(10, 132, 255, 0.08)',
  chartGradientTop: 'rgba(10, 132, 255, 0.25)',
  chartGradientBottom: 'rgba(10, 132, 255, 0.0)',
};

const FONTS = {
  system: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Arial, sans-serif',
  mono: '"SF Mono", "Fira Code", "Cascadia Code", Menlo, monospace',
};

function getBaseStyles() {
  return `
    :host {
      all: initial;
      font-family: ${FONTS.system};
      color: ${COLORS.text};
      font-size: 13px;
      line-height: 1.47;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .cl-panel {
      position: fixed;
      top: 72px;
      right: 16px;
      width: 380px;
      max-height: calc(100vh - 88px);
      background: ${COLORS.bg};
      backdrop-filter: blur(80px) saturate(180%);
      -webkit-backdrop-filter: blur(80px) saturate(180%);
      border: 1px solid ${COLORS.border};
      border-radius: 16px;
      box-shadow:
        0 0 0 0.5px rgba(255,255,255,0.05),
        0 24px 80px rgba(0,0,0,0.55),
        0 8px 24px rgba(0,0,0,0.3);
      overflow: hidden;
      z-index: 2147483647;
      opacity: 0;
      transform: translateY(-8px) scale(0.98);
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1),
                  transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      display: flex;
      flex-direction: column;
    }

    .cl-panel.visible {
      opacity: 1;
      transform: translateY(0) scale(1);
    }

    .cl-panel.collapsed {
      width: 380px;
      max-height: 52px;
      overflow: hidden;
    }

    .cl-scrollable {
      overflow-y: auto;
      overflow-x: hidden;
      flex: 1;
      padding: 0 16px 16px;
      scrollbar-width: thin;
      scrollbar-color: rgba(255,255,255,0.1) transparent;
    }

    .cl-scrollable::-webkit-scrollbar {
      width: 6px;
    }
    .cl-scrollable::-webkit-scrollbar-track {
      background: transparent;
    }
    .cl-scrollable::-webkit-scrollbar-thumb {
      background: rgba(255,255,255,0.1);
      border-radius: 3px;
    }
    .cl-scrollable::-webkit-scrollbar-thumb:hover {
      background: rgba(255,255,255,0.2);
    }

    /* Header */
    .cl-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      border-bottom: 1px solid ${COLORS.border};
      cursor: grab;
      user-select: none;
      flex-shrink: 0;
    }

    .cl-header:active { cursor: grabbing; }

    .cl-logo {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .cl-logo-icon {
      width: 24px;
      height: 24px;
      border-radius: 6px;
      background: linear-gradient(135deg, ${COLORS.accent}, ${COLORS.purple});
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .cl-logo-text {
      font-size: 13px;
      font-weight: 600;
      letter-spacing: -0.01em;
    }

    .cl-header-actions {
      display: flex;
      gap: 4px;
    }

    .cl-icon-btn {
      width: 28px;
      height: 28px;
      border-radius: 7px;
      border: none;
      background: transparent;
      color: ${COLORS.textSecondary};
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
      font-family: inherit;
    }

    .cl-icon-btn:hover {
      background: ${COLORS.surface};
      color: ${COLORS.text};
    }

    /* Channel info */
    .cl-channel {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px 0 12px;
    }

    .cl-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      object-fit: cover;
      flex-shrink: 0;
      background: ${COLORS.surface};
    }

    .cl-channel-info {
      flex: 1;
      min-width: 0;
    }

    .cl-channel-name {
      font-size: 15px;
      font-weight: 600;
      letter-spacing: -0.02em;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .cl-channel-handle {
      font-size: 12px;
      color: ${COLORS.textSecondary};
      margin-top: 1px;
    }

    /* Stats grid */
    .cl-stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      padding: 8px 0 16px;
    }

    .cl-stat {
      background: ${COLORS.surface};
      border-radius: 12px;
      padding: 12px;
      text-align: center;
      border: 1px solid ${COLORS.border};
      transition: all 0.2s ease;
    }

    .cl-stat:hover {
      background: ${COLORS.surfaceHover};
      border-color: ${COLORS.borderLight};
    }

    .cl-stat-value {
      font-size: 18px;
      font-weight: 700;
      letter-spacing: -0.03em;
      font-variant-numeric: tabular-nums;
    }

    .cl-stat-label {
      font-size: 10px;
      color: ${COLORS.textTertiary};
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-top: 2px;
      font-weight: 500;
    }

    /* Section */
    .cl-section {
      padding: 12px 0;
    }

    .cl-section + .cl-section {
      border-top: 1px solid ${COLORS.border};
    }

    .cl-section-title {
      font-size: 11px;
      font-weight: 600;
      color: ${COLORS.textTertiary};
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin-bottom: 12px;
    }

    /* Revenue cards */
    .cl-revenue-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }

    .cl-revenue-card {
      background: ${COLORS.surface};
      border: 1px solid ${COLORS.border};
      border-radius: 12px;
      padding: 12px;
      transition: all 0.2s ease;
    }

    .cl-revenue-card:hover {
      border-color: ${COLORS.borderLight};
    }

    .cl-revenue-label {
      font-size: 10px;
      color: ${COLORS.textTertiary};
      text-transform: uppercase;
      letter-spacing: 0.04em;
      font-weight: 500;
    }

    .cl-revenue-value {
      font-size: 16px;
      font-weight: 700;
      letter-spacing: -0.02em;
      margin-top: 4px;
      color: ${COLORS.green};
    }

    .cl-revenue-range {
      font-size: 10px;
      color: ${COLORS.textTertiary};
      margin-top: 2px;
    }

    /* Chart container */
    .cl-chart-container {
      background: ${COLORS.surface};
      border: 1px solid ${COLORS.border};
      border-radius: 12px;
      padding: 16px;
      margin: 8px 0;
    }

    .cl-chart-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }

    .cl-chart-title {
      font-size: 12px;
      font-weight: 600;
      color: ${COLORS.textSecondary};
    }

    .cl-chart-value-label {
      font-size: 11px;
      color: ${COLORS.textTertiary};
    }

    .cl-chart-svg {
      width: 100%;
      overflow: visible;
    }

    /* Competitor cards */
    .cl-competitor {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px;
      background: ${COLORS.surface};
      border: 1px solid ${COLORS.border};
      border-radius: 12px;
      margin-bottom: 6px;
      cursor: pointer;
      transition: all 0.2s ease;
      text-decoration: none;
      color: inherit;
    }

    .cl-competitor:hover {
      background: ${COLORS.surfaceHover};
      border-color: ${COLORS.borderLight};
      transform: translateY(-1px);
    }

    .cl-competitor-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      object-fit: cover;
      flex-shrink: 0;
      background: ${COLORS.bgSolid};
    }

    .cl-competitor-info {
      flex: 1;
      min-width: 0;
    }

    .cl-competitor-name {
      font-size: 13px;
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .cl-competitor-meta {
      font-size: 11px;
      color: ${COLORS.textTertiary};
      margin-top: 1px;
      display: flex;
      gap: 8px;
    }

    .cl-competitor-badge {
      font-size: 10px;
      padding: 2px 8px;
      border-radius: 6px;
      font-weight: 600;
      white-space: nowrap;
    }

    .cl-badge-up {
      background: ${COLORS.greenSoft};
      color: ${COLORS.green};
    }

    .cl-badge-down {
      background: ${COLORS.redSoft};
      color: ${COLORS.red};
    }

    .cl-badge-same {
      background: ${COLORS.surface};
      color: ${COLORS.textSecondary};
    }

    /* Loading */
    .cl-loading {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 40px 16px;
      gap: 12px;
    }

    .cl-spinner {
      width: 24px;
      height: 24px;
      border: 2px solid ${COLORS.border};
      border-top-color: ${COLORS.accent};
      border-radius: 50%;
      animation: cl-spin 0.8s linear infinite;
    }

    @keyframes cl-spin {
      to { transform: rotate(360deg); }
    }

    .cl-loading-text {
      font-size: 12px;
      color: ${COLORS.textTertiary};
    }

    /* Shimmer */
    .cl-shimmer {
      background: linear-gradient(90deg,
        ${COLORS.surface} 0%,
        rgba(255,255,255,0.06) 50%,
        ${COLORS.surface} 100%);
      background-size: 200% 100%;
      animation: cl-shimmer 1.5s ease-in-out infinite;
      border-radius: 8px;
    }

    @keyframes cl-shimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }

    /* Error / empty */
    .cl-empty {
      text-align: center;
      padding: 32px 16px;
      color: ${COLORS.textTertiary};
      font-size: 12px;
    }

    .cl-error {
      text-align: center;
      padding: 24px 16px;
      color: ${COLORS.red};
      font-size: 12px;
    }

    /* Setup prompt */
    .cl-setup {
      padding: 24px;
      text-align: center;
    }

    .cl-setup h3 {
      font-size: 15px;
      font-weight: 600;
      margin-bottom: 8px;
    }

    .cl-setup p {
      font-size: 12px;
      color: ${COLORS.textSecondary};
      margin-bottom: 16px;
      line-height: 1.5;
    }

    .cl-setup-input {
      width: 100%;
      padding: 10px 12px;
      background: ${COLORS.surface};
      border: 1px solid ${COLORS.border};
      border-radius: 10px;
      color: ${COLORS.text};
      font-size: 13px;
      font-family: ${FONTS.mono};
      outline: none;
      transition: border-color 0.2s ease;
      margin-bottom: 12px;
    }

    .cl-setup-input:focus {
      border-color: ${COLORS.accent};
    }

    .cl-setup-input::placeholder {
      color: ${COLORS.textTertiary};
    }

    .cl-btn {
      padding: 8px 20px;
      border-radius: 10px;
      border: none;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s ease;
      font-family: inherit;
    }

    .cl-btn-primary {
      background: ${COLORS.accent};
      color: #fff;
    }

    .cl-btn-primary:hover {
      filter: brightness(1.1);
    }

    .cl-btn-primary:active {
      transform: scale(0.97);
    }

    /* Fade-in animation for sections */
    .cl-fade-in {
      opacity: 0;
      transform: translateY(6px);
      animation: cl-fade-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }

    @keyframes cl-fade-in {
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Stagger delays */
    .cl-delay-1 { animation-delay: 0.05s; }
    .cl-delay-2 { animation-delay: 0.1s; }
    .cl-delay-3 { animation-delay: 0.15s; }
    .cl-delay-4 { animation-delay: 0.2s; }
    .cl-delay-5 { animation-delay: 0.25s; }
    .cl-delay-6 { animation-delay: 0.3s; }

    /* Toggle button (floating) */
    .cl-toggle {
      position: fixed;
      top: 72px;
      right: 16px;
      width: 40px;
      height: 40px;
      border-radius: 12px;
      background: ${COLORS.bg};
      backdrop-filter: blur(40px) saturate(180%);
      -webkit-backdrop-filter: blur(40px) saturate(180%);
      border: 1px solid ${COLORS.border};
      box-shadow: 0 4px 16px rgba(0,0,0,0.3);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2147483646;
      transition: all 0.2s ease;
      color: ${COLORS.textSecondary};
    }

    .cl-toggle:hover {
      background: ${COLORS.surfaceHover};
      color: ${COLORS.text};
      transform: scale(1.05);
    }

    .cl-toggle.active {
      background: linear-gradient(135deg, ${COLORS.accent}, ${COLORS.purple});
      color: #fff;
      border-color: transparent;
    }

    /* Tabs */
    .cl-tabs {
      display: flex;
      gap: 2px;
      padding: 8px 16px;
      background: transparent;
      flex-shrink: 0;
    }

    .cl-tab {
      flex: 1;
      padding: 7px 0;
      border: none;
      background: transparent;
      color: ${COLORS.textTertiary};
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      border-radius: 8px;
      transition: all 0.15s ease;
      font-family: inherit;
      letter-spacing: -0.01em;
    }

    .cl-tab:hover {
      color: ${COLORS.textSecondary};
      background: ${COLORS.surface};
    }

    .cl-tab.active {
      color: ${COLORS.text};
      background: ${COLORS.surface};
    }

    /* Number animation */
    .cl-count-up {
      font-variant-numeric: tabular-nums;
    }

    /* Tooltip */
    .cl-tooltip {
      position: relative;
    }

    .cl-tooltip::after {
      content: attr(data-tip);
      position: absolute;
      bottom: calc(100% + 6px);
      left: 50%;
      transform: translateX(-50%);
      padding: 4px 8px;
      background: ${COLORS.bgSolid};
      border: 1px solid ${COLORS.border};
      border-radius: 6px;
      font-size: 10px;
      color: ${COLORS.textSecondary};
      white-space: nowrap;
      pointer-events: none;
      opacity: 0;
      transition: opacity 0.15s ease;
    }

    .cl-tooltip:hover::after {
      opacity: 1;
    }
  `;
}
// Hand-crafted SVG line chart — Apple style
// Zero dependencies, smooth cubic bezier curves, animated draw-in



function createLineChart(data, options = {}) {
  const {
    width = 320,
    height = 140,
    color = COLORS.accent,
    fillColor = COLORS.chartFill,
    gradientTop = COLORS.chartGradientTop,
    gradientBottom = COLORS.chartGradientBottom,
    showDots = true,
    showLabels = true,
    showGrid = true,
    valueKey = 'value',
    labelKey = 'label',
    formatValue = (v) => v.toLocaleString(),
    animate = true,
  } = options;

  if (!data || data.length < 2) return createEmptyChart(width, height);

  const padding = { top: 8, right: 12, bottom: showLabels ? 28 : 8, left: 12 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const values = data.map(d => typeof d === 'number' ? d : d[valueKey]);
  const labels = data.map(d => typeof d === 'object' ? d[labelKey] : '');
  const maxVal = Math.max(...values) || 1;
  const minVal = Math.min(...values);
  const range = maxVal - minVal || 1;

  // Map data to chart coordinates
  const points = values.map((v, i) => ({
    x: padding.left + (i / (values.length - 1)) * chartW,
    y: padding.top + chartH - ((v - minVal) / range) * chartH,
    value: v,
    label: labels[i],
  }));

  // Build smooth cubic bezier path
  const linePath = smoothPath(points);
  const areaPath = linePath +
    ` L ${points[points.length - 1].x},${padding.top + chartH}` +
    ` L ${points[0].x},${padding.top + chartH} Z`;

  const gradientId = 'clGrad_' + Math.random().toString(36).slice(2, 8);
  const clipId = 'clClip_' + Math.random().toString(36).slice(2, 8);

  let gridLines = '';
  if (showGrid) {
    const gridSteps = 3;
    for (let i = 0; i <= gridSteps; i++) {
      const y = padding.top + (chartH / gridSteps) * i;
      gridLines += `<line x1="${padding.left}" y1="${y}" x2="${padding.left + chartW}" y2="${y}" stroke="${COLORS.border}" stroke-width="0.5"/>`;
    }
  }

  let labelElements = '';
  if (showLabels && labels.some(l => l)) {
    const step = Math.max(1, Math.floor(labels.length / 5));
    for (let i = 0; i < labels.length; i += step) {
      if (labels[i]) {
        labelElements += `<text x="${points[i].x}" y="${height - 4}" fill="${COLORS.textTertiary}" font-size="9" text-anchor="middle" font-family="-apple-system, sans-serif">${labels[i]}</text>`;
      }
    }
  }

  let dotElements = '';
  if (showDots) {
    // Only show last dot for minimalism
    const last = points[points.length - 1];
    dotElements = `
      <circle cx="${last.x}" cy="${last.y}" r="3.5" fill="${color}" opacity="0.9">
        ${animate ? '<animate attributeName="r" from="0" to="3.5" dur="0.4s" begin="0.6s" fill="freeze"/>' : ''}
      </circle>
      <circle cx="${last.x}" cy="${last.y}" r="7" fill="${color}" opacity="0.15">
        ${animate ? '<animate attributeName="r" from="0" to="7" dur="0.4s" begin="0.6s" fill="freeze"/>' : ''}
      </circle>
    `;
  }

  // Hover interaction areas (invisible rects for each data point)
  let hoverAreas = '';
  const segmentW = chartW / (points.length - 1);
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    hoverAreas += `
      <rect x="${p.x - segmentW / 2}" y="${padding.top}" width="${segmentW}" height="${chartH}"
        fill="transparent" data-idx="${i}" class="cl-chart-hover-area"/>
    `;
  }

  const animationStyle = animate ? `
    .cl-line-path { stroke-dasharray: 1000; stroke-dashoffset: 1000; animation: cl-draw-line 1s cubic-bezier(0.16, 1, 0.3, 1) 0.1s forwards; }
    .cl-area-path { opacity: 0; animation: cl-fade-area 0.6s ease 0.5s forwards; }
    @keyframes cl-draw-line { to { stroke-dashoffset: 0; } }
    @keyframes cl-fade-area { to { opacity: 1; } }
  ` : '';

  const svg = `
    <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" class="cl-chart-svg">
      <defs>
        <linearGradient id="${gradientId}" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="${gradientTop}"/>
          <stop offset="100%" stop-color="${gradientBottom}"/>
        </linearGradient>
        <clipPath id="${clipId}">
          <rect x="${padding.left}" y="${padding.top}" width="${chartW}" height="${chartH}"/>
        </clipPath>
      </defs>
      <style>${animationStyle}</style>
      <g clip-path="url(#${clipId})">
        ${gridLines}
        <path d="${areaPath}" fill="url(#${gradientId})" class="cl-area-path"/>
        <path d="${linePath}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="cl-line-path"/>
        ${dotElements}
      </g>
      ${labelElements}
      ${hoverAreas}
    </svg>
  `;

  return { svg, points, formatValue };
}

function smoothPath(points) {
  if (points.length < 2) return '';
  if (points.length === 2) {
    return `M ${points[0].x},${points[0].y} L ${points[1].x},${points[1].y}`;
  }

  let path = `M ${points[0].x},${points[0].y}`;

  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(points.length - 1, i + 2)];

    const tension = 0.3;
    const cp1x = p1.x + (p2.x - p0.x) * tension;
    const cp1y = p1.y + (p2.y - p0.y) * tension;
    const cp2x = p2.x - (p3.x - p1.x) * tension;
    const cp2y = p2.y - (p3.y - p1.y) * tension;

    path += ` C ${cp1x},${cp1y} ${cp2x},${cp2y} ${p2.x},${p2.y}`;
  }

  return path;
}

function createEmptyChart(width, height) {
  return {
    svg: `
      <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" class="cl-chart-svg">
        <text x="${width / 2}" y="${height / 2}" fill="${COLORS.textTertiary}" font-size="11" text-anchor="middle" font-family="-apple-system, sans-serif">No data available</text>
      </svg>
    `,
    points: [],
    formatValue: (v) => v.toString(),
  };
}

function createBarChart(data, options = {}) {
  const {
    width = 320,
    height = 120,
    color = COLORS.accent,
    barRadius = 4,
    valueKey = 'value',
    labelKey = 'label',
    animate = true,
  } = options;

  if (!data || data.length === 0) return { svg: '', points: [] };

  const padding = { top: 8, right: 8, bottom: 28, left: 8 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const values = data.map(d => typeof d === 'number' ? d : d[valueKey]);
  const labels = data.map(d => typeof d === 'object' ? d[labelKey] : '');
  const maxVal = Math.max(...values) || 1;

  const barGap = 4;
  const barW = Math.max(4, (chartW - barGap * (values.length - 1)) / values.length);

  let bars = '';
  let labelElements = '';
  const step = Math.max(1, Math.floor(values.length / 6));

  for (let i = 0; i < values.length; i++) {
    const barH = Math.max(2, (values[i] / maxVal) * chartH);
    const x = padding.left + i * (barW + barGap);
    const y = padding.top + chartH - barH;
    const opacity = 0.4 + (values[i] / maxVal) * 0.6;

    bars += `
      <rect x="${x}" y="${animate ? padding.top + chartH : y}" width="${barW}" height="${animate ? 0 : barH}"
        rx="${Math.min(barRadius, barW / 2)}" fill="${color}" opacity="${opacity}">
        ${animate ? `<animate attributeName="y" from="${padding.top + chartH}" to="${y}" dur="0.5s" begin="${i * 0.03}s" fill="freeze" calcMode="spline" keySplines="0.16 1 0.3 1"/>
        <animate attributeName="height" from="0" to="${barH}" dur="0.5s" begin="${i * 0.03}s" fill="freeze" calcMode="spline" keySplines="0.16 1 0.3 1"/>` : ''}
      </rect>
    `;

    if (i % step === 0 && labels[i]) {
      labelElements += `<text x="${x + barW / 2}" y="${height - 4}" fill="${COLORS.textTertiary}" font-size="9" text-anchor="middle" font-family="-apple-system, sans-serif">${labels[i]}</text>`;
    }
  }

  return {
    svg: `
      <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" class="cl-chart-svg">
        ${bars}
        ${labelElements}
      </svg>
    `,
    points: values.map((v, i) => ({ x: padding.left + i * (barW + barGap) + barW / 2, y: padding.top + chartH - (v / maxVal) * chartH, value: v })),
  };
}
// Main panel UI — injected into YouTube pages
// Apple-style floating panel with deep channel analysis




class ChannelPanel {
  constructor() {
    this.host = null;
    this.shadow = null;
    this.panel = null;
    this.toggle = null;
    this.isOpen = false;
    this.isDragging = false;
    this.dragOffset = { x: 0, y: 0 };
    this.currentTab = 'overview';
    this.data = null;
    this.isLoading = false;
  }

  mount() {
    this.host = document.createElement('div');
    this.host.id = 'channellens-root';
    document.body.appendChild(this.host);
    this.shadow = this.host.attachShadow({ mode: 'closed' });

    const style = document.createElement('style');
    style.textContent = getBaseStyles();
    this.shadow.appendChild(style);

    this.toggle = document.createElement('button');
    this.toggle.className = 'cl-toggle';
    this.toggle.appendChild(this._createLensIcon(20));
    this.toggle.addEventListener('click', () => this.togglePanel());
    this.shadow.appendChild(this.toggle);

    this.panel = document.createElement('div');
    this.panel.className = 'cl-panel';
    this.shadow.appendChild(this.panel);

    this._renderEmpty();
  }

  unmount() {
    this.host?.remove();
  }

  togglePanel() {
    this.isOpen = !this.isOpen;
    this.panel.classList.toggle('visible', this.isOpen);
    this.toggle.classList.toggle('active', this.isOpen);
  }

  showLoading() {
    this.isLoading = true;
    if (!this.isOpen) this.togglePanel();
    this._clearPanel();

    this.panel.appendChild(this._buildHeader());
    const loading = this._el('div', 'cl-loading');
    loading.appendChild(this._el('div', 'cl-spinner'));
    const text = this._el('div', 'cl-loading-text');
    text.textContent = 'Analyzing channel...';
    loading.appendChild(text);
    this.panel.appendChild(loading);
  }

  showSetup() {
    if (!this.isOpen) this.togglePanel();
    this._clearPanel();

    this.panel.appendChild(this._buildHeader());
    const scroll = this._el('div', 'cl-scrollable');
    const setup = this._el('div', 'cl-setup cl-fade-in');

    const emoji = this._el('div');
    emoji.textContent = '🔑';
    emoji.style.cssText = 'font-size:32px;margin-bottom:12px';
    setup.appendChild(emoji);

    const h3 = this._el('h3');
    h3.textContent = 'YouTube API Key';
    setup.appendChild(h3);

    const p = this._el('p');
    p.textContent = 'To analyze channels, ChannelLens needs a YouTube Data API v3 key. Get one free from Google Cloud Console.';
    setup.appendChild(p);

    const input = this._el('input', 'cl-setup-input');
    input.type = 'text';
    input.placeholder = 'AIzaSy...';
    input.spellcheck = false;
    input.autocomplete = 'off';
    setup.appendChild(input);

    const btn = this._el('button', 'cl-btn cl-btn-primary');
    btn.textContent = 'Save & Analyze';
    btn.addEventListener('click', () => {
      const key = input.value?.trim();
      if (key) this.onSaveApiKey?.(key);
    });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') btn.click(); });
    setup.appendChild(btn);

    scroll.appendChild(setup);
    this.panel.appendChild(scroll);
  }

  showError(message) {
    this._clearPanel();
    this.panel.appendChild(this._buildHeader());
    const scroll = this._el('div', 'cl-scrollable');
    const err = this._el('div', 'cl-error cl-fade-in');
    const icon = this._el('div');
    icon.textContent = '⚠️';
    icon.style.cssText = 'font-size:24px;margin-bottom:8px';
    err.appendChild(icon);
    const msg = this._el('div');
    msg.textContent = message;
    err.appendChild(msg);
    scroll.appendChild(err);
    this.panel.appendChild(scroll);
  }

  showData(data) {
    this.data = data;
    this.isLoading = false;
    this._renderData();
  }

  _renderData() {
    if (!this.data) return;
    const { channel, videos, uploadFrequency, revenue, competitors } = this.data;

    this._clearPanel();
    this.panel.appendChild(this._buildHeader());

    // Tabs
    const tabs = this._el('div', 'cl-tabs');
    for (const t of ['overview', 'revenue', 'competitors']) {
      const btn = this._el('button', `cl-tab${this.currentTab === t ? ' active' : ''}`);
      btn.textContent = t === 'overview' ? 'Overview' : t === 'revenue' ? 'Revenue' : 'Rivals';
      btn.dataset.tab = t;
      btn.addEventListener('click', () => { this.currentTab = t; this._renderData(); });
      tabs.appendChild(btn);
    }
    this.panel.appendChild(tabs);

    const scroll = this._el('div', 'cl-scrollable');

    if (this.currentTab === 'overview') this._buildOverview(scroll, channel, videos, uploadFrequency);
    else if (this.currentTab === 'revenue') this._buildRevenue(scroll, channel, revenue);
    else if (this.currentTab === 'competitors') this._buildCompetitors(scroll, channel, competitors);

    this.panel.appendChild(scroll);
  }

  _buildOverview(container, channel, videos, uploadFrequency) {
    const avgViews = videos && videos.length > 0
      ? Math.round(videos.slice(0, 20).reduce((s, v) => s + v.viewCount, 0) / Math.min(20, videos.length))
      : 0;

    // Channel info
    const chDiv = this._el('div', 'cl-channel cl-fade-in cl-delay-1');
    if (channel.thumbnailURL) {
      const img = this._el('img', 'cl-avatar');
      img.src = channel.thumbnailURL;
      img.alt = channel.title;
      chDiv.appendChild(img);
    }
    const info = this._el('div', 'cl-channel-info');
    const name = this._el('div', 'cl-channel-name');
    name.textContent = channel.title;
    info.appendChild(name);
    const handle = this._el('div', 'cl-channel-handle');
    handle.textContent = channel.customUrl ? '@' + channel.customUrl.replace('@', '') : channel.id;
    info.appendChild(handle);
    chDiv.appendChild(info);
    container.appendChild(chDiv);

    // Stats
    container.appendChild(this._buildStatsGrid([
      { value: this._formatCount(channel.subscriberCount), label: 'Subscribers' },
      { value: this._formatCount(channel.viewCount), label: 'Views' },
      { value: this._formatCount(channel.videoCount), label: 'Videos' },
    ], 'cl-fade-in cl-delay-2'));

    container.appendChild(this._buildStatsGrid([
      { value: this._formatCount(avgViews), label: 'Avg Views', small: true },
      { value: this._channelAge(channel.publishedAt), label: 'Channel Age', small: true },
      { value: channel.country || '—', label: 'Country', small: true },
    ], 'cl-fade-in cl-delay-3', true));

    // Upload frequency chart
    if (uploadFrequency && uploadFrequency.length > 1) {
      const section = this._el('div', 'cl-section cl-fade-in cl-delay-4');
      const title = this._el('div', 'cl-section-title');
      title.textContent = 'Upload Frequency';
      section.appendChild(title);

      const chartData = uploadFrequency.slice(-12).map(u => ({
        value: u.count, label: this._shortMonth(u.date),
      }));
      const chart = createBarChart(chartData, { width: 316, height: 100, color: COLORS.accent });
      const chartContainer = this._el('div', 'cl-chart-container');
      const header = this._buildChartHeader('Videos per month', 'Last 12 months');
      chartContainer.appendChild(header);
      chartContainer.insertAdjacentHTML('beforeend', chart.svg);
      section.appendChild(chartContainer);
      container.appendChild(section);
    }

    // Views chart
    if (uploadFrequency && uploadFrequency.length > 1) {
      const section = this._el('div', 'cl-section cl-fade-in cl-delay-5');
      const title = this._el('div', 'cl-section-title');
      title.textContent = 'Monthly Views';
      section.appendChild(title);

      const chartData = uploadFrequency.slice(-12).map(u => ({
        value: u.totalViews, label: this._shortMonth(u.date),
      }));
      const chart = createLineChart(chartData, {
        width: 316, height: 120, color: COLORS.green,
        gradientTop: 'rgba(48, 209, 88, 0.2)', gradientBottom: 'rgba(48, 209, 88, 0.0)',
      });
      const chartContainer = this._el('div', 'cl-chart-container');
      const header = this._buildChartHeader('Total views per month', '12 months');
      chartContainer.appendChild(header);
      chartContainer.insertAdjacentHTML('beforeend', chart.svg);
      section.appendChild(chartContainer);
      container.appendChild(section);
    }

    // Topics
    if (channel.topicCategories?.length > 0) {
      const section = this._el('div', 'cl-section cl-fade-in cl-delay-6');
      const title = this._el('div', 'cl-section-title');
      title.textContent = 'Topics';
      section.appendChild(title);
      const wrap = this._el('div');
      wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px';
      for (const t of channel.topicCategories) {
        const tag = this._el('span');
        tag.textContent = t;
        tag.style.cssText = `padding:4px 10px;background:${COLORS.surface};border:1px solid ${COLORS.border};border-radius:8px;font-size:11px;color:${COLORS.textSecondary}`;
        wrap.appendChild(tag);
      }
      section.appendChild(wrap);
      container.appendChild(section);
    }
  }

  _buildRevenue(container, channel, revenue) {
    if (!revenue) {
      const empty = this._el('div', 'cl-empty');
      empty.textContent = 'Revenue data not available';
      container.appendChild(empty);
      return;
    }

    const midMonthly = (revenue.monthlyRevenue.low + revenue.monthlyRevenue.high) / 2;
    const midYearly = (revenue.yearlyRevenue.low + revenue.yearlyRevenue.high) / 2;
    const midPerVideo = (revenue.revenuePerVideo.low + revenue.revenuePerVideo.high) / 2;

    // Revenue cards
    const section = this._el('div', 'cl-section cl-fade-in cl-delay-1');
    const title = this._el('div', 'cl-section-title');
    title.textContent = 'Estimated Revenue';
    section.appendChild(title);

    const grid = this._el('div', 'cl-revenue-grid');
    grid.appendChild(this._buildRevenueCard('Monthly', this._formatCurrency(midMonthly), `${this._formatCurrency(revenue.monthlyRevenue.low)} – ${this._formatCurrency(revenue.monthlyRevenue.high)}`));
    grid.appendChild(this._buildRevenueCard('Yearly', this._formatCurrency(midYearly), `${this._formatCurrency(revenue.yearlyRevenue.low)} – ${this._formatCurrency(revenue.yearlyRevenue.high)}`));
    grid.appendChild(this._buildRevenueCard('Per Video', this._formatCurrency(midPerVideo), `${this._formatCurrency(revenue.revenuePerVideo.low)} – ${this._formatCurrency(revenue.revenuePerVideo.high)}`));
    grid.appendChild(this._buildRevenueCard('CPM', `${revenue.estimatedCPM.low.toFixed(1)} – ${revenue.estimatedCPM.high.toFixed(1)}`, revenue.category || 'General', COLORS.accent));
    section.appendChild(grid);
    container.appendChild(section);

    // Monthly views card
    const section2 = this._el('div', 'cl-section cl-fade-in cl-delay-2');
    const card = this._el('div');
    card.style.cssText = `background:${COLORS.surface};border:1px solid ${COLORS.border};border-radius:12px;padding:14px;display:flex;justify-content:space-between;align-items:center`;
    const left = this._el('div');
    const label = this._el('div');
    label.textContent = 'Monthly Views';
    label.style.cssText = `font-size:10px;color:${COLORS.textTertiary};text-transform:uppercase;letter-spacing:0.04em;font-weight:500`;
    left.appendChild(label);
    const val = this._el('div');
    val.textContent = this._formatCount(revenue.monthlyViewsEstimate);
    val.style.cssText = 'font-size:20px;font-weight:700;letter-spacing:-0.03em;margin-top:4px';
    left.appendChild(val);
    card.appendChild(left);
    const iconBox = this._el('div');
    iconBox.textContent = '📊';
    iconBox.style.cssText = `width:40px;height:40px;border-radius:10px;background:${COLORS.greenSoft};display:flex;align-items:center;justify-content:center;font-size:18px`;
    card.appendChild(iconBox);
    section2.appendChild(card);
    container.appendChild(section2);

    // Revenue chart
    if (revenue.revenueHistory?.length > 1) {
      const section3 = this._el('div', 'cl-section cl-fade-in cl-delay-3');
      const title3 = this._el('div', 'cl-section-title');
      title3.textContent = 'Revenue Trend';
      section3.appendChild(title3);

      const chartData = revenue.revenueHistory.slice(-12).reverse().map(r => ({
        value: (r.estimatedLow + r.estimatedHigh) / 2,
        label: this._shortMonth(r.date),
      }));
      const chart = createLineChart(chartData, {
        width: 316, height: 140, color: COLORS.green,
        gradientTop: 'rgba(48, 209, 88, 0.25)', gradientBottom: 'rgba(48, 209, 88, 0.0)',
      });
      const chartContainer = this._el('div', 'cl-chart-container');
      chartContainer.appendChild(this._buildChartHeader('Estimated monthly revenue', '12 months'));
      chartContainer.insertAdjacentHTML('beforeend', chart.svg);
      section3.appendChild(chartContainer);
      container.appendChild(section3);
    }

    // Disclaimer
    const disc = this._el('div', 'cl-section cl-fade-in cl-delay-4');
    const discText = this._el('div');
    discText.textContent = 'Revenue estimates are based on public view data and industry-average CPM rates. Actual earnings depend on ad rates, demographics, sponsorships, and other factors.';
    discText.style.cssText = `font-size:10px;color:${COLORS.textTertiary};line-height:1.5;padding:8px 0`;
    disc.appendChild(discText);
    container.appendChild(disc);
  }

  _buildCompetitors(container, channel, competitors) {
    if (!competitors?.length) {
      const empty = this._el('div', 'cl-empty cl-fade-in');
      empty.textContent = 'No competitors found';
      container.appendChild(empty);
      return;
    }

    const section = this._el('div', 'cl-section cl-fade-in cl-delay-1');
    const title = this._el('div', 'cl-section-title');
    title.textContent = 'Similar Channels';
    section.appendChild(title);

    competitors.forEach((comp, i) => {
      const c = comp.channel;
      const subRatio = comp.comparison.subscriberRatio;
      const subLabel = subRatio > 1.05 ? `${((subRatio - 1) * 100).toFixed(0)}% more subs`
        : subRatio < 0.95 ? `${((1 - subRatio) * 100).toFixed(0)}% fewer subs` : 'Similar size';
      const badgeClass = subRatio > 1.05 ? 'cl-badge-up' : subRatio < 0.95 ? 'cl-badge-down' : 'cl-badge-same';

      const a = this._el('a', `cl-competitor cl-fade-in cl-delay-${Math.min(6, i + 2)}`);
      a.href = `https://www.youtube.com/channel/${encodeURIComponent(c.id)}`;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';

      if (c.thumbnailURL) {
        const img = this._el('img', 'cl-competitor-avatar');
        img.src = c.thumbnailURL;
        img.alt = c.title;
        a.appendChild(img);
      }

      const infoDiv = this._el('div', 'cl-competitor-info');
      const nameEl = this._el('div', 'cl-competitor-name');
      nameEl.textContent = c.title;
      infoDiv.appendChild(nameEl);
      const meta = this._el('div', 'cl-competitor-meta');
      const sub = this._el('span');
      sub.textContent = this._formatCount(c.subscriberCount) + ' subs';
      meta.appendChild(sub);
      const vid = this._el('span');
      vid.textContent = this._formatCount(c.videoCount) + ' videos';
      meta.appendChild(vid);
      infoDiv.appendChild(meta);
      a.appendChild(infoDiv);

      const badge = this._el('span', `cl-competitor-badge ${badgeClass}`);
      badge.textContent = subLabel;
      a.appendChild(badge);

      section.appendChild(a);
    });
    container.appendChild(section);

    // Comparison bars
    const section2 = this._el('div', 'cl-section cl-fade-in cl-delay-5');
    const title2 = this._el('div', 'cl-section-title');
    title2.textContent = 'Subscriber Comparison';
    section2.appendChild(title2);
    const chartContainer = this._el('div', 'cl-chart-container');
    this._buildComparisonBars(chartContainer, channel, competitors);
    section2.appendChild(chartContainer);
    container.appendChild(section2);
  }

  _buildComparisonBars(container, channel, competitors) {
    const all = [
      { name: channel.title, subs: channel.subscriberCount, isTarget: true },
      ...competitors.map(c => ({ name: c.channel.title, subs: c.channel.subscriberCount, isTarget: false })),
    ].sort((a, b) => b.subs - a.subs);
    const maxSubs = all[0]?.subs || 1;

    all.forEach((item, i) => {
      const pct = Math.max(3, (item.subs / maxSubs) * 100);
      const row = this._el('div');
      row.style.cssText = `display:flex;align-items:center;gap:10px;${i < all.length - 1 ? 'margin-bottom:8px' : ''}`;

      const label = this._el('div');
      label.textContent = item.name.length > 12 ? item.name.slice(0, 11) + '…' : item.name;
      label.style.cssText = `width:80px;flex-shrink:0;font-size:11px;color:${item.isTarget ? COLORS.text : COLORS.textSecondary};font-weight:${item.isTarget ? '600' : '400'};white-space:nowrap;overflow:hidden;text-overflow:ellipsis`;
      row.appendChild(label);

      const barBg = this._el('div');
      barBg.style.cssText = `flex:1;height:20px;background:${COLORS.surface};border-radius:6px;overflow:hidden;border:1px solid ${COLORS.border}`;
      const barFill = this._el('div');
      barFill.style.cssText = `height:100%;width:${pct}%;background:${item.isTarget ? COLORS.accent : 'rgba(255,255,255,0.08)'};border-radius:5px;transition:width 0.8s cubic-bezier(0.16, 1, 0.3, 1)`;
      barBg.appendChild(barFill);
      row.appendChild(barBg);

      const valEl = this._el('div');
      valEl.textContent = this._formatCount(item.subs);
      valEl.style.cssText = `width:50px;flex-shrink:0;text-align:right;font-size:11px;font-weight:600;color:${item.isTarget ? COLORS.accent : COLORS.textSecondary};font-variant-numeric:tabular-nums`;
      row.appendChild(valEl);

      container.appendChild(row);
    });
  }

  // === Builder helpers ===

  _buildHeader() {
    const header = this._el('div', 'cl-header');
    header.id = 'cl-drag-handle';

    const logo = this._el('div', 'cl-logo');
    const iconBox = this._el('div', 'cl-logo-icon');
    iconBox.appendChild(this._createLensIcon(14, '#fff'));
    logo.appendChild(iconBox);
    const logoText = this._el('span', 'cl-logo-text');
    logoText.textContent = 'ChannelLens';
    logo.appendChild(logoText);
    header.appendChild(logo);

    const actions = this._el('div', 'cl-header-actions');
    const refreshBtn = this._el('button', 'cl-icon-btn');
    refreshBtn.title = 'Refresh';
    refreshBtn.insertAdjacentHTML('beforeend', '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>');
    refreshBtn.addEventListener('click', () => this.onRefresh?.());
    actions.appendChild(refreshBtn);

    const closeBtn = this._el('button', 'cl-icon-btn');
    closeBtn.title = 'Close';
    closeBtn.insertAdjacentHTML('beforeend', '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>');
    closeBtn.addEventListener('click', () => this.togglePanel());
    actions.appendChild(closeBtn);

    header.appendChild(actions);

    // Drag
    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('.cl-icon-btn')) return;
      this.isDragging = true;
      const rect = this.panel.getBoundingClientRect();
      this.dragOffset.x = e.clientX - rect.left;
      this.dragOffset.y = e.clientY - rect.top;
      const onMove = (e2) => {
        if (!this.isDragging) return;
        this.panel.style.left = (e2.clientX - this.dragOffset.x) + 'px';
        this.panel.style.top = (e2.clientY - this.dragOffset.y) + 'px';
        this.panel.style.right = 'auto';
      };
      const onUp = () => {
        this.isDragging = false;
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    return header;
  }

  _buildStatsGrid(items, className, noPadTop) {
    const grid = this._el('div', `cl-stats ${className}`);
    if (noPadTop) grid.style.paddingTop = '0';
    for (const item of items) {
      const stat = this._el('div', 'cl-stat');
      const val = this._el('div', 'cl-stat-value');
      if (item.small) val.style.fontSize = '15px';
      val.textContent = item.value;
      stat.appendChild(val);
      const label = this._el('div', 'cl-stat-label');
      label.textContent = item.label;
      stat.appendChild(label);
      grid.appendChild(stat);
    }
    return grid;
  }

  _buildRevenueCard(labelText, valueText, rangeText, color) {
    const card = this._el('div', 'cl-revenue-card');
    const label = this._el('div', 'cl-revenue-label');
    label.textContent = labelText;
    card.appendChild(label);
    const val = this._el('div', 'cl-revenue-value');
    val.textContent = valueText;
    if (color) val.style.color = color;
    card.appendChild(val);
    const range = this._el('div', 'cl-revenue-range');
    range.textContent = rangeText;
    card.appendChild(range);
    return card;
  }

  _buildChartHeader(titleText, rightText) {
    const header = this._el('div', 'cl-chart-header');
    const t = this._el('span', 'cl-chart-title');
    t.textContent = titleText;
    header.appendChild(t);
    const r = this._el('span', 'cl-chart-value-label');
    r.textContent = rightText;
    header.appendChild(r);
    return header;
  }

  _renderEmpty() {
    this._clearPanel();
    this.panel.appendChild(this._buildHeader());
    const scroll = this._el('div', 'cl-scrollable');
    const empty = this._el('div', 'cl-empty cl-fade-in');
    const icon = this._el('div');
    icon.textContent = '🔍';
    icon.style.cssText = 'font-size:28px;margin-bottom:8px';
    empty.appendChild(icon);
    const msg = this._el('div');
    msg.textContent = 'Navigate to a YouTube channel';
    msg.style.cssText = `font-size:13px;font-weight:500;color:${COLORS.textSecondary};margin-bottom:4px`;
    empty.appendChild(msg);
    const sub = this._el('div');
    sub.textContent = 'ChannelLens will automatically detect and analyze it';
    sub.style.cssText = 'font-size:11px';
    empty.appendChild(sub);
    scroll.appendChild(empty);
    this.panel.appendChild(scroll);
  }

  _clearPanel() {
    while (this.panel.firstChild) this.panel.removeChild(this.panel.firstChild);
  }

  _el(tag, className) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    return el;
  }

  _createLensIcon(size = 20, color = 'currentColor') {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('width', size);
    svg.setAttribute('height', size);
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', color);
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    const circle = document.createElementNS(ns, 'circle');
    circle.setAttribute('cx', '11');
    circle.setAttribute('cy', '11');
    circle.setAttribute('r', '8');
    svg.appendChild(circle);
    const path1 = document.createElementNS(ns, 'path');
    path1.setAttribute('d', 'M21 21l-4.35-4.35');
    svg.appendChild(path1);
    const path2 = document.createElementNS(ns, 'path');
    path2.setAttribute('d', 'M8 11h6');
    path2.setAttribute('stroke-width', '1.5');
    svg.appendChild(path2);
    const path3 = document.createElementNS(ns, 'path');
    path3.setAttribute('d', 'M11 8v6');
    path3.setAttribute('stroke-width', '1.5');
    svg.appendChild(path3);
    return svg;
  }

  _formatCount(n) {
    if (n == null) return '—';
    n = Number(n);
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n.toString();
  }

  _formatCurrency(n) {
    if (n >= 1e6) return '$' + (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return '$' + (n / 1e3).toFixed(1) + 'K';
    return '$' + Math.round(n);
  }

  _channelAge(publishedAt) {
    if (!publishedAt) return '—';
    const d = new Date(publishedAt);
    const now = new Date();
    const totalMonths = (now.getFullYear() - d.getFullYear()) * 12 + (now.getMonth() - d.getMonth());
    if (totalMonths >= 12) return Math.floor(totalMonths / 12) + 'y ' + (totalMonths % 12) + 'm';
    return totalMonths + 'm';
  }

  _shortMonth(date) {
    if (!date) return '';
    const d = new Date(date);
    return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
  }

  // Callbacks
  onSaveApiKey = null;
  onRefresh = null;
}
// YouTube channel detector
// Extracts channel info from the current YouTube page URL and DOM

function detectChannel() {
  const url = window.location.href;
  const pathname = window.location.pathname;

  // Pattern: /@handle or /@handle/videos etc
  const handleMatch = pathname.match(/^\/@([^/]+)/);
  if (handleMatch) {
    return { type: 'handle', value: handleMatch[1], handle: '@' + handleMatch[1] };
  }

  // Pattern: /channel/UCxxxx
  const channelIdMatch = pathname.match(/^\/channel\/(UC[a-zA-Z0-9_-]+)/);
  if (channelIdMatch) {
    return { type: 'channelId', value: channelIdMatch[1] };
  }

  // Pattern: /c/CustomName (legacy)
  const customMatch = pathname.match(/^\/c\/([^/]+)/);
  if (customMatch) {
    return { type: 'handle', value: customMatch[1], handle: customMatch[1] };
  }

  // Pattern: /user/Username (legacy)
  const userMatch = pathname.match(/^\/user\/([^/]+)/);
  if (userMatch) {
    return { type: 'handle', value: userMatch[1], handle: userMatch[1] };
  }

  // On a video page, try to get channel from the page
  if (pathname.startsWith('/watch')) {
    return detectChannelFromVideoPage();
  }

  return null;
}

function detectChannelFromVideoPage() {
  // Try to find channel link in video page
  const channelLink = document.querySelector(
    'ytd-video-owner-renderer a.yt-simple-endpoint, ' +
    '#owner a.yt-simple-endpoint, ' +
    'ytd-channel-name a.yt-simple-endpoint'
  );

  if (channelLink) {
    const href = channelLink.getAttribute('href') || '';
    const handleMatch = href.match(/^\/@([^/]+)/);
    if (handleMatch) {
      return { type: 'handle', value: handleMatch[1], handle: '@' + handleMatch[1] };
    }
    const channelIdMatch = href.match(/^\/channel\/(UC[a-zA-Z0-9_-]+)/);
    if (channelIdMatch) {
      return { type: 'channelId', value: channelIdMatch[1] };
    }
  }

  // Try meta tags
  const ogUrl = document.querySelector('meta[property="og:url"]');
  if (ogUrl) {
    const content = ogUrl.getAttribute('content') || '';
    const match = content.match(/youtube\.com\/(channel|@|c|user)\/([^/?]+)/);
    if (match) {
      if (match[1] === 'channel') return { type: 'channelId', value: match[2] };
      return { type: 'handle', value: match[2], handle: match[2] };
    }
  }

  return null;
}

function isChannelPage() {
  const path = window.location.pathname;
  return path.startsWith('/@') ||
         path.startsWith('/channel/') ||
         path.startsWith('/c/') ||
         path.startsWith('/user/');
}

function isVideoPage() {
  return window.location.pathname.startsWith('/watch');
}
// Content script — main entry point
// Runs on every YouTube page, detects channels, manages the panel




let panel = null;
let lastChannelId = null;
let lastAnalyzedId = null;

function init() {
  panel = new ChannelPanel();
  panel.mount();

  panel.onSaveApiKey = async (key) => {
    await chrome.runtime.sendMessage({ type: 'SET_API_KEY', apiKey: key });
    const detected = detectChannel();
    if (detected) analyzeChannel(detected);
  };

  panel.onRefresh = () => {
    const detected = detectChannel();
    if (detected) analyzeChannel(detected, true);
  };

  // Initial check
  checkPage();

  // Watch for YouTube SPA navigation
  observeNavigation();
}

function checkPage() {
  const detected = detectChannel();
  if (!detected) {
    lastChannelId = null;
    return;
  }

  const id = detected.value;
  if (id !== lastChannelId) {
    lastChannelId = id;
    checkApiKeyAndAnalyze(detected);
  }
}

async function checkApiKeyAndAnalyze(detected) {
  const res = await chrome.runtime.sendMessage({ type: 'CHECK_API_KEY' });
  if (!res.hasKey) {
    panel.showSetup();
    return;
  }
  analyzeChannel(detected);
}

async function analyzeChannel(detected, force = false) {
  try {
    // First resolve channel ID if we have a handle
    let channelId;
    if (detected.type === 'channelId') {
      channelId = detected.value;
    } else {
      panel.showLoading();
      const chRes = await chrome.runtime.sendMessage({
        type: 'FETCH_CHANNEL',
        handle: detected.handle || detected.value,
      });
      if (chRes.error) {
        if (chRes.error === 'NO_API_KEY') { panel.showSetup(); return; }
        panel.showError('Could not find channel: ' + detected.value);
        return;
      }
      channelId = chRes.channel.id;
    }

    if (channelId === lastAnalyzedId && !force) return;
    lastAnalyzedId = channelId;

    panel.showLoading();

    const result = await chrome.runtime.sendMessage({
      type: 'FETCH_FULL_ANALYSIS',
      channelId,
    });

    if (result.error) {
      panel.showError(result.error === 'NO_API_KEY' ? 'API key required' : result.error);
      return;
    }

    panel.showData(result);

  } catch (err) {
    panel.showError('Analysis failed: ' + (err.message || 'Unknown error'));
  }
}

function observeNavigation() {
  // YouTube uses SPA navigation — watch for URL changes
  let currentUrl = location.href;

  const observer = new MutationObserver(() => {
    if (location.href !== currentUrl) {
      currentUrl = location.href;
      // Small delay for YouTube to update the DOM
      setTimeout(checkPage, 800);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });

  // Also listen for popstate (back/forward)
  window.addEventListener('popstate', () => {
    setTimeout(checkPage, 500);
  });

  // And yt-navigate-finish (YouTube's own event)
  window.addEventListener('yt-navigate-finish', () => {
    setTimeout(checkPage, 300);
  });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
