// Popup script for API key management

document.addEventListener('DOMContentLoaded', async () => {
  const input = document.getElementById('apiKeyInput');
  const saveBtn = document.getElementById('saveBtn');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const successMsg = document.getElementById('successMsg');

  // Load existing key
  const result = await chrome.storage.sync.get('youtubeApiKey');
  if (result.youtubeApiKey) {
    input.value = result.youtubeApiKey;
    statusDot.className = 'status-dot active';
    statusText.textContent = 'Connected — API key configured';
  } else {
    statusDot.className = 'status-dot inactive';
    statusText.textContent = 'Not configured — enter API key above';
  }

  saveBtn.addEventListener('click', async () => {
    const key = input.value.trim();
    if (!key) return;

    await chrome.storage.sync.set({ youtubeApiKey: key });
    statusDot.className = 'status-dot active';
    statusText.textContent = 'Connected — API key configured';
    successMsg.style.display = 'block';
    setTimeout(() => { successMsg.style.display = 'none'; }, 2000);
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') saveBtn.click();
  });
});
