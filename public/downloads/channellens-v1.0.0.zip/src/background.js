// YouTube Data API v3 service
// All API calls go through the background service worker to avoid CORS

const API_BASE = 'https://www.googleapis.com/youtube/v3';

async function fetchChannelByHandle(handle, apiKey) {
  // Try forHandle first (for @handles)
  const cleanHandle = handle.startsWith('@') ? handle.slice(1) : handle;
  const url = `${API_BASE}/channels?part=snippet,statistics,topicDetails,brandingSettings&forHandle=${encodeURIComponent(cleanHandle)}&key=${apiKey}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`YouTube API error: ${res.status}`);
  const data = await res.json();
  if (data.items && data.items.length > 0) return parseChannel(data.items[0]);
  return null;
}

async function fetchChannelById(channelId, apiKey) {
  const url = `${API_BASE}/channels?part=snippet,statistics,topicDetails,brandingSettings&id=${channelId}&key=${apiKey}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`YouTube API error: ${res.status}`);
  const data = await res.json();
  if (data.items && data.items.length > 0) return parseChannel(data.items[0]);
  return null;
}

async function fetchChannelVideos(channelId, apiKey, maxResults = 50) {
  // First get the uploads playlist
  const channelUrl = `${API_BASE}/channels?part=contentDetails&id=${channelId}&key=${apiKey}`;
  const channelRes = await fetch(channelUrl);
  const channelData = await channelRes.json();
  const uploadsPlaylistId = channelData.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
  if (!uploadsPlaylistId) return [];

  // Fetch playlist items (up to 150 for good history)
  let allItems = [];
  let pageToken = '';
  const pages = Math.ceil(Math.min(maxResults, 150) / 50);

  for (let i = 0; i < pages; i++) {
    const plUrl = `${API_BASE}/playlistItems?part=snippet,contentDetails&playlistId=${uploadsPlaylistId}&maxResults=50&key=${apiKey}${pageToken ? '&pageToken=' + pageToken : ''}`;
    const plRes = await fetch(plUrl);
    const plData = await plRes.json();
    if (plData.items) allItems.push(...plData.items);
    pageToken = plData.nextPageToken || '';
    if (!pageToken) break;
  }

  // Get video statistics in batches of 50
  const videoIds = allItems.map(item => item.contentDetails?.videoId).filter(Boolean);
  const videos = [];

  for (let i = 0; i < videoIds.length; i += 50) {
    const batch = videoIds.slice(i, i + 50);
    const vUrl = `${API_BASE}/videos?part=statistics,contentDetails,snippet&id=${batch.join(',')}&key=${apiKey}`;
    const vRes = await fetch(vUrl);
    const vData = await vRes.json();
    if (vData.items) {
      videos.push(...vData.items.map(parseVideo));
    }
  }

  return videos;
}

async function searchRelatedChannels(query, apiKey, maxResults = 10) {
  const url = `${API_BASE}/search?part=snippet&type=channel&q=${encodeURIComponent(query)}&maxResults=${maxResults}&key=${apiKey}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`YouTube API error: ${res.status}`);
  const data = await res.json();
  return data.items?.map(item => ({
    channelId: item.snippet?.channelId || item.id?.channelId,
    title: item.snippet?.title,
    description: item.snippet?.description,
    thumbnailUrl: item.snippet?.thumbnails?.medium?.url,
  })) || [];
}

async function fetchMultipleChannels(channelIds, apiKey) {
  const channels = [];
  for (let i = 0; i < channelIds.length; i += 50) {
    const batch = channelIds.slice(i, i + 50);
    const url = `${API_BASE}/channels?part=snippet,statistics,topicDetails&id=${batch.join(',')}&key=${apiKey}`;
    const res = await fetch(url);
    const data = await res.json();
    if (data.items) {
      channels.push(...data.items.map(parseChannel));
    }
  }
  return channels;
}

function parseChannel(item) {
  const s = item.snippet || {};
  const st = item.statistics || {};
  const t = item.topicDetails || {};
  const b = item.brandingSettings || {};
  return {
    id: item.id,
    title: s.title || '',
    description: s.description || '',
    customUrl: s.customUrl || null,
    thumbnailURL: s.thumbnails?.high?.url || s.thumbnails?.medium?.url || null,
    bannerURL: b.image?.bannerExternalUrl || null,
    subscriberCount: parseInt(st.subscriberCount || '0', 10),
    videoCount: parseInt(st.videoCount || '0', 10),
    viewCount: parseInt(st.viewCount || '0', 10),
    publishedAt: s.publishedAt || null,
    country: s.country || null,
    topicCategories: (t.topicCategories || []).map(url => {
      const parts = url.split('/');
      return parts[parts.length - 1].replace(/_/g, ' ');
    }),
  };
}

function parseVideo(item) {
  const s = item.snippet || {};
  const st = item.statistics || {};
  const cd = item.contentDetails || {};
  return {
    id: item.id,
    title: s.title || '',
    publishedAt: s.publishedAt || null,
    thumbnailURL: s.thumbnails?.medium?.url || null,
    viewCount: parseInt(st.viewCount || '0', 10),
    likeCount: parseInt(st.likeCount || '0', 10),
    commentCount: parseInt(st.commentCount || '0', 10),
    duration: parseDuration(cd.duration || 'PT0S'),
  };
}

function parseDuration(iso) {
  const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 0;
  return (parseInt(match[1] || '0') * 3600) +
         (parseInt(match[2] || '0') * 60) +
         parseInt(match[3] || '0');
}
// Revenue estimation engine
// Based on public data: views, video count, channel category, country

const CPM_RANGES = {
  // Category-based CPM ranges (USD per 1000 monetized views)
  'Finance': { low: 12, high: 36 },
  'Business': { low: 10, high: 30 },
  'Technology': { low: 4, high: 15 },
  'Education': { low: 3, high: 12 },
  'How-to & Style': { low: 3, high: 10 },
  'Gaming': { low: 2, high: 8 },
  'Entertainment': { low: 2, high: 7 },
  'Music': { low: 1, high: 5 },
  'Sports': { low: 2, high: 8 },
  'News & Politics': { low: 3, high: 12 },
  'Science & Technology': { low: 4, high: 14 },
  'People & Blogs': { low: 1.5, high: 6 },
  'Film & Animation': { low: 2, high: 8 },
  'Pets & Animals': { low: 2, high: 7 },
  'Travel & Events': { low: 3, high: 12 },
  'Autos & Vehicles': { low: 4, high: 15 },
  'Comedy': { low: 2, high: 7 },
  'Nonprofits & Activism': { low: 1, high: 5 },
  'default': { low: 2, high: 8 },
};

// Country multipliers for CPM
const COUNTRY_MULTIPLIERS = {
  'US': 1.0, 'CA': 0.9, 'GB': 0.85, 'AU': 0.85, 'DE': 0.8,
  'FR': 0.75, 'JP': 0.7, 'KR': 0.65, 'BR': 0.3, 'IN': 0.15,
  'RU': 0.25, 'MX': 0.25, 'ID': 0.15, 'PH': 0.15, 'default': 0.5,
};

// Monetization rate — not all views are monetized (ad-blocked, skipped, non-monetizable)
const MONETIZATION_RATE = 0.55;

function estimateRevenue(channel, videos) {
  const category = detectCategory(channel.topicCategories);
  const cpmRange = CPM_RANGES[category] || CPM_RANGES['default'];
  const countryMult = COUNTRY_MULTIPLIERS[channel.country] || COUNTRY_MULTIPLIERS['default'];

  const adjustedCPM = {
    low: cpmRange.low * countryMult,
    high: cpmRange.high * countryMult,
  };

  // Calculate monthly views from recent videos
  const recentVideos = videos.filter(v => v.publishedAt).sort((a, b) =>
    new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );

  // Group videos by month for history
  const monthlyData = groupByMonth(recentVideos);
  const revenueHistory = monthlyData.map(month => ({
    date: month.date,
    views: month.totalViews,
    estimatedLow: (month.totalViews / 1000) * adjustedCPM.low * MONETIZATION_RATE,
    estimatedHigh: (month.totalViews / 1000) * adjustedCPM.high * MONETIZATION_RATE,
  }));

  // Estimate monthly views (average of last 3 months if available)
  const recentMonths = revenueHistory.slice(0, 3);
  const monthlyViewsEstimate = recentMonths.length > 0
    ? Math.round(recentMonths.reduce((sum, m) => sum + m.views, 0) / recentMonths.length)
    : Math.round(channel.viewCount / Math.max(1, getChannelAgeMonths(channel)));

  const monthlyRevenueLow = (monthlyViewsEstimate / 1000) * adjustedCPM.low * MONETIZATION_RATE;
  const monthlyRevenueHigh = (monthlyViewsEstimate / 1000) * adjustedCPM.high * MONETIZATION_RATE;

  // Per-video average
  const avgViews = recentVideos.length > 0
    ? recentVideos.slice(0, 20).reduce((s, v) => s + v.viewCount, 0) / Math.min(20, recentVideos.length)
    : channel.viewCount / Math.max(1, channel.videoCount);

  const perVideoLow = (avgViews / 1000) * adjustedCPM.low * MONETIZATION_RATE;
  const perVideoHigh = (avgViews / 1000) * adjustedCPM.high * MONETIZATION_RATE;

  // Top video revenue
  const topVideo = recentVideos.length > 0
    ? recentVideos.reduce((best, v) => v.viewCount > best.viewCount ? v : best, recentVideos[0])
    : null;

  return {
    monthlyViewsEstimate,
    estimatedCPM: { low: adjustedCPM.low, high: adjustedCPM.high },
    monthlyRevenue: { low: monthlyRevenueLow, high: monthlyRevenueHigh },
    yearlyRevenue: { low: monthlyRevenueLow * 12, high: monthlyRevenueHigh * 12 },
    revenuePerVideo: { low: perVideoLow, high: perVideoHigh },
    topVideoRevenue: topVideo ? {
      low: (topVideo.viewCount / 1000) * adjustedCPM.low * MONETIZATION_RATE,
      high: (topVideo.viewCount / 1000) * adjustedCPM.high * MONETIZATION_RATE,
    } : null,
    revenueHistory,
    category,
    cpmRange: adjustedCPM,
  };
}

function detectCategory(topics) {
  if (!topics || topics.length === 0) return 'default';
  for (const topic of topics) {
    for (const key of Object.keys(CPM_RANGES)) {
      if (topic.toLowerCase().includes(key.toLowerCase())) return key;
    }
  }
  return 'default';
}

function getChannelAgeMonths(channel) {
  if (!channel.publishedAt) return 12;
  const created = new Date(channel.publishedAt);
  const now = new Date();
  return Math.max(1, (now.getFullYear() - created.getFullYear()) * 12 + (now.getMonth() - created.getMonth()));
}

function groupByMonth(videos) {
  const groups = {};
  for (const video of videos) {
    if (!video.publishedAt) continue;
    const date = new Date(video.publishedAt);
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    if (!groups[key]) {
      groups[key] = {
        date: new Date(date.getFullYear(), date.getMonth(), 1),
        count: 0,
        totalViews: 0,
        videos: [],
      };
    }
    groups[key].count++;
    groups[key].totalViews += video.viewCount;
    groups[key].videos.push(video);
  }
  return Object.values(groups).sort((a, b) => b.date.getTime() - a.date.getTime());
}

function computeUploadFrequency(videos) {
  const groups = groupByMonth(videos);
  return groups.map(g => ({
    date: g.date,
    count: g.count,
    totalViews: g.totalViews,
  })).reverse(); // chronological order
}
// Competitor finding engine
// Uses YouTube search + topic matching to find similar channels



async function findCompetitors(channel, apiKey, limit = 5) {
  // Build search queries from channel info
  const queries = buildSearchQueries(channel);

  // Search for related channels
  const candidateMap = new Map();

  for (const query of queries.slice(0, 3)) {
    const results = await searchRelatedChannels(query, apiKey, 15);
    for (const result of results) {
      if (result.channelId && result.channelId !== channel.id) {
        if (!candidateMap.has(result.channelId)) {
          candidateMap.set(result.channelId, { ...result, searchHits: 1 });
        } else {
          candidateMap.get(result.channelId).searchHits++;
        }
      }
    }
  }

  if (candidateMap.size === 0) return [];

  // Fetch full channel data for candidates
  const candidateIds = Array.from(candidateMap.keys()).slice(0, 20);
  const candidateChannels = await fetchMultipleChannels(candidateIds, apiKey);

  // Score and rank competitors
  const scored = candidateChannels.map(comp => {
    const searchData = candidateMap.get(comp.id);
    const score = computeRelevanceScore(channel, comp, searchData?.searchHits || 1);
    const sharedTopics = findSharedTopics(channel, comp);

    return {
      id: comp.id,
      channel: comp,
      relevanceScore: score,
      sharedTopics,
      comparison: {
        subscriberRatio: channel.subscriberCount > 0 ? comp.subscriberCount / channel.subscriberCount : 0,
        viewRatio: channel.viewCount > 0 ? comp.viewCount / channel.viewCount : 0,
        uploadFrequencyRatio: channel.videoCount > 0 ? comp.videoCount / channel.videoCount : 0,
        avgViewsPerVideo: comp.videoCount > 0 ? Math.round(comp.viewCount / comp.videoCount) : 0,
        targetAvgViewsPerVideo: channel.videoCount > 0 ? Math.round(channel.viewCount / channel.videoCount) : 0,
      },
    };
  });

  // Sort by relevance and return top N
  scored.sort((a, b) => b.relevanceScore - a.relevanceScore);
  return scored.slice(0, limit);
}

function buildSearchQueries(channel) {
  const queries = [];

  // Use topic categories
  if (channel.topicCategories && channel.topicCategories.length > 0) {
    queries.push(channel.topicCategories.slice(0, 2).join(' ') + ' YouTube channel');
  }

  // Use channel title keywords
  const titleWords = channel.title.split(/\s+/).filter(w => w.length > 2);
  if (titleWords.length > 0) {
    queries.push(titleWords.slice(0, 3).join(' '));
  }

  // Use description keywords
  if (channel.description) {
    const descWords = channel.description
      .split(/\s+/)
      .filter(w => w.length > 3 && !w.startsWith('http'))
      .slice(0, 5);
    if (descWords.length >= 2) {
      queries.push(descWords.slice(0, 3).join(' '));
    }
  }

  // Fallback: generic category search
  if (queries.length === 0) {
    queries.push(channel.title + ' similar channels');
  }

  return queries;
}

function computeRelevanceScore(target, candidate, searchHits) {
  let score = 0;

  // Topic overlap
  const sharedTopics = findSharedTopics(target, candidate);
  score += sharedTopics.length * 20;

  // Similar size (subscribers within 10x)
  if (target.subscriberCount > 0 && candidate.subscriberCount > 0) {
    const ratio = candidate.subscriberCount / target.subscriberCount;
    if (ratio >= 0.1 && ratio <= 10) score += 30;
    if (ratio >= 0.3 && ratio <= 3) score += 20;
  }

  // Same country
  if (target.country && candidate.country && target.country === candidate.country) {
    score += 10;
  }

  // Search hit bonus
  score += searchHits * 15;

  // Active channel bonus (recent uploads)
  if (candidate.videoCount > 10) score += 10;

  return score;
}

function findSharedTopics(a, b) {
  if (!a.topicCategories || !b.topicCategories) return [];
  const aSet = new Set(a.topicCategories.map(t => t.toLowerCase()));
  return b.topicCategories.filter(t => aSet.has(t.toLowerCase()));
}
// Background service worker
// Handles YouTube API calls and state management





// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message).then(sendResponse).catch(err => {
    sendResponse({ error: err.message });
  });
  return true; // async response
});

async function handleMessage(msg) {
  const apiKey = await getApiKey();
  if (!apiKey && msg.type !== 'SET_API_KEY' && msg.type !== 'GET_API_KEY' && msg.type !== 'CHECK_API_KEY') {
    return { error: 'NO_API_KEY' };
  }

  switch (msg.type) {
    case 'CHECK_API_KEY': {
      const key = await getApiKey();
      return { hasKey: !!key };
    }

    case 'SET_API_KEY': {
      await chrome.storage.sync.set({ youtubeApiKey: msg.apiKey });
      return { success: true };
    }

    case 'GET_API_KEY': {
      return { apiKey: await getApiKey() };
    }

    case 'FETCH_CHANNEL': {
      let channel;
      if (msg.channelId) {
        channel = await fetchChannelById(msg.channelId, apiKey);
      } else if (msg.handle) {
        channel = await fetchChannelByHandle(msg.handle, apiKey);
      }
      if (!channel) return { error: 'CHANNEL_NOT_FOUND' };
      return { channel };
    }

    case 'FETCH_FULL_ANALYSIS': {
      const { channelId } = msg;
      const channel = await fetchChannelById(channelId, apiKey);
      if (!channel) return { error: 'CHANNEL_NOT_FOUND' };

      // Fetch videos for history
      const videos = await fetchChannelVideos(channelId, apiKey, 150);

      // Compute upload frequency
      const uploadFrequency = computeUploadFrequency(videos);

      // Estimate revenue
      const revenue = estimateRevenue(channel, videos);

      // Find competitors
      const competitors = await findCompetitors(channel, apiKey, 5);

      return {
        channel,
        videos: videos.slice(0, 30), // Latest 30 for display
        uploadFrequency,
        revenue,
        competitors,
      };
    }

    default:
      return { error: 'UNKNOWN_MESSAGE_TYPE' };
  }
}

async function getApiKey() {
  const result = await chrome.storage.sync.get('youtubeApiKey');
  return result.youtubeApiKey || null;
}

// Open popup on install
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.action.openPopup?.();
  }
});
